const alexaSDK = require('alexa-sdk');
const awsSDK = require('aws-sdk');
const {promisify} = require('es6-promisify');

const appId = 'amzn1.ask.skill.0a1c8811-9ba9-4e0f-a7cf-3b27cf414bf6';
const foodTable = 'Nutrition';
const docClient = new awsSDK.DynamoDB.DocumentClient();

// convert callback style functions to promises
const dbScan = promisify(docClient.scan, docClient);
const dbGet = promisify(docClient.get, docClient);
const dbPut = promisify(docClient.put, docClient);
const dbDelete = promisify(docClient.delete, docClient);

const instructions = `Welcome to Nutrition Assistant. 
                      The following commands are available: add food, get summary, 
                      and delete food. What would you like to do?`;

const handlers = {

  /**
   * Triggered when the user says "Alexa, open Nutrition App.
   */
  'LaunchRequest'() {
    this.emit(':ask', instructions);
  },

  /**
   * Adds a recipe to the current user's saved recipes.
   * Slots: FoodName, Servings
   */
  'AddFoodIntent'() {
    const { userId } = this.event.session.user;
    const { slots } = this.event.request.intent;

    // prompt for slot values and request a confirmation for each

    // RecipeName
    if (!slots.FoodName.value) {
      const slotToElicit = 'FoodName';
      const speechOutput = 'What is the name of the food?';
      const repromptSpeech = 'Please tell me the name of the food';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }
    else if (slots.FoodName.confirmationStatus !== 'CONFIRMED') {

      if (slots.FoodName.confirmationStatus !== 'DENIED') {
        // slot status: unconfirmed
        const slotToConfirm = 'FoodName';
        const speechOutput = `The name of the food is ${slots.FoodName.value}, correct?`;
        const repromptSpeech = speechOutput;
        return this.emit(':confirmSlot', slotToConfirm, speechOutput, repromptSpeech);
      }

      // slot status: denied -> reprompt for slot data
      const slotToElicit = 'FoodName';
      const speechOutput = 'What is the name of the food you would like to add?';
      const repromptSpeech = 'Please tell me the name of the food';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }

    // Servings
    if (!slots.Servings.value) {
      const slotToElicit = 'Servings';
      const speechOutput = 'How many servings did you eat?';
      const repromptSpeech = 'Please tell me how many servings you ate.';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }
    else if (slots.Servings.confirmationStatus !== 'CONFIRMED') {

      if (slots.Servings.confirmationStatus !== 'DENIED') {
        // slot status: unconfirmed
        const slotToConfirm = 'Servings';
        const speechOutput = `You ate ${slots.Servings.value} servings, correct?`;
        const repromptSpeech = speechOutput;
        return this.emit(':confirmSlot', slotToConfirm, speechOutput, repromptSpeech);
      }

      // slot status: denied -> reprompt for slot data
      const slotToElicit = 'Servings';
      const speechOutput = 'How many servings did you eat?';
      const repromptSpeech = 'Please tell me how many servings you ate.';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }



    // all slot values received and confirmed, now add the record to DynamoDB

    const name = slots.FoodName.value;
    const servings = slots.Servings.value;
    const dynamoParams = {
      TableName: foodTable,
      Item: {
        Name: name,
        UserID: userId,
        Servings: servings,
      }
    };

    console.log('Attempting to add food', dynamoParams);

    // query DynamoDB to see if the item exists first
    docClient.put(dynamoParams).promise()
      .then(data => {
        console.log('Add item succeeded', data);

        this.emit(':tell', `${name} added!`);
      })
      .catch(err => {
        console.error(err);
      });
  },

  /**
   * Lists all saved recipes for the current user. The user can filter by quick or long recipes.
   * Slots: GetFood
   */
  'GetSummaryIntent'() {
    const { userId } = this.event.session.user;
    let output;
    
    const dynamoParams = {
      TableName: foodTable
    };

    dynamoParams.FilterExpression = 'UserID = :user_id';
    dynamoParams.ExpressionAttributeValues = { ':user_id': userId };
    output = 'The following foods were found: <break strength="x-strong" />';
    

    // query DynamoDB
    docClient.scan(dynamoParams).promise()
      .then(data => {
        console.log('Read table succeeded!', data);

        if (data.Items && data.Items.length) {
          data.Items.forEach(item => { output += `${item.Name}, <break strength="x-strong" />`; });
        }
        else {
          output = 'No food found!';
        }

        console.log('output', output);

        this.emit(':tell', output);
      })
      .catch(err => {
        console.error(err);
      });
  },


  /**
   * Allow the user to delete one of their foods.
   */
  'DeleteFoodIntent'() {
    const { slots } = this.event.request.intent;

    // prompt for the food name if needed and then require a confirmation
    if (!slots.FoodName.value) {
      const slotToElicit = 'FoodName';
      const speechOutput = 'What is the name of the food you would like to delete?';
      const repromptSpeech = 'Please tell me the name of the food';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }
    else if (slots.FoodName.confirmationStatus !== 'CONFIRMED') {

      if (slots.FoodName.confirmationStatus !== 'DENIED') {
        // slot status: unconfirmed
        const slotToConfirm = 'FoodName';
        const speechOutput = `You would like to delete ${slots.FoodName.value}, correct?`;
        const repromptSpeech = speechOutput;
        return this.emit(':confirmSlot', slotToConfirm, speechOutput, repromptSpeech);
      }

      // slot status: denied -> reprompt for slot data
      const slotToElicit = 'FoodName';
      const speechOutput = 'What is the name of the food you would like to delete?';
      const repromptSpeech = 'Please tell me the name of the food';
      return this.emit(':elicitSlot', slotToElicit, speechOutput, repromptSpeech);
    }

    const { userId } = this.event.session.user;
    const foodName = slots.FoodName.value;
    const dynamoParams = {
      TableName: foodTable,
      Key: {
        Name: foodName,
        UserID: userId
      }
    };

    console.log('Attempting to read data');

    // query DynamoDB to see if the item exists first
    docClient.get(dynamoParams).promise()
      .then(data => {
        console.log('Get item succeeded', data);

        const food = data.Item;

        if (food) {
          console.log('Attempting to delete data', data);

          return docClient.delete(dynamoParams).promise();
        }

        const errorMsg = `Food ${foodName} not found!`;
        this.emit(':tell', errorMsg);
        throw new Error(errorMsg);
      })
      .then(data => {
        console.log('Delete item succeeded', data);

        this.emit(':tell', `Food ${foodName} deleted!`);
      })
      .catch(err => console.log(err));
  },

  'Unhandled'() {
    console.error('problem', this.event);
    this.emit(':ask', 'An unhandled problem occurred!');
  },

  'AMAZON.HelpIntent'() {
    const speechOutput = instructions;
    const reprompt = instructions;
    this.emit(':ask', speechOutput, reprompt);
  },

  'AMAZON.CancelIntent'() {
    this.emit(':tell', 'Goodbye!');
  },

  'AMAZON.StopIntent'() {
    this.emit(':tell', 'Goodbye!');
  }
};

exports.handler = function handler(event, context) {
  const alexa = alexaSDK.handler(event, context);
  alexa.APP_ID = appId;
  alexa.registerHandlers(handlers);
  alexa.execute();
};